<?php
/**
 * Shine Express — PHP bootstrap (no Composer).
 * Document root should point to /public on shared hosting.
 */

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('PUBLIC_PATH', BASE_PATH . '/public');

require BASE_PATH . '/app/Helpers/functions.php';
require BASE_PATH . '/app/Core/Autoloader.php';

App\Core\Autoloader::register(APP_PATH);

$config = require APP_PATH . '/Config/app.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Kolkata');

if (($config['debug'] ?? false) === true) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', '0');
}

App\Core\Session::start();

// CORS preflight for mobile API
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    http_response_code(204);
    exit;
}

$router = new App\Core\Router();
require APP_PATH . '/Config/routes.php';
require APP_PATH . '/Config/api_routes.php';

$router->dispatch(
    App\Core\Request::method(),
    App\Core\Request::path()
);
